from dataclasses import dataclass

import pandas as pd
from sklearn.model_selection import GridSearchCV


@dataclass
class Results:
    model: str
    params: dict
    roc_auc_train: float
    roc_auc_test: float


def run_experiment(pipeline, param_grid, data, target):
    """
    Running gridsearch for different types of estimators. Passed estimator is attached as a last
    step of the pipeline and whole object is train/tested using 4 fold cross validation.

    :param pipeline: sklearn pipeline with estimator object as a last step
    :param param_grid: grid of parameters which all combinations will be run using GridSearch
    :param data: data that will be used for training
    :param target: labels for a given data

    :return: Results objects with estimator name, its configuration and train and test roc_auc
             score
    """

    grid = GridSearchCV(
        pipeline,
        param_grid=param_grid,
        cv=4,
        scoring='roc_auc',
        return_train_score=True,
    )

    grid.fit(data, target)
    results = grid.cv_results_

    estimator_name = pipeline.steps[-1][1].__class__.__name__

    return [Results(estimator_name, params, train_score, test_score)
            for params, train_score, test_score
            in zip(results['params'], results['mean_train_score'], results['mean_test_score'])]


def get_results_as_dataframe(results):
    """
    Building dataframe with experiment results
    """
    return (pd.DataFrame([result.__dict__ for result in results])
            .sort_values('roc_auc_test'))


def get_best_models_for_each_estimator_type(results):
    """
    Return dictionary with best model settings for each estimator type
    """

    best_model_params = dict()
    scores_df = get_results_as_dataframe(results)

    for _, row in scores_df.drop_duplicates(subset=['model'], keep='last').iterrows():
        best_model_params[row['model']] = \
            {parameter.split("__")[1]: value for parameter, value in row['params'].items()}

    return best_model_params
