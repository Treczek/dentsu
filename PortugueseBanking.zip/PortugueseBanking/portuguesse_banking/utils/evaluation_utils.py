from sklearn.utils.validation import check_is_fitted
from sklearn.exceptions import NotFittedError
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt


def calculate_roc_auc(model, X, y):
    prediction = model.predict_proba(X)[:, 1]
    return round(roc_auc_score(y, prediction), 3)


def calculate_fpr_tpr(model, X, y):
    prediction = model.predict_proba(X)[:, 1]
    fpr, tpr, _ = roc_curve(y, prediction)
    return fpr, tpr


def draw_roc(name, fpr, tpr, ax=None):
    if not ax:
        fig, ax = plt.subplots(1, 1, figsize=(8, 8))

    ax.plot(fpr, tpr, label=name)
    ax.plot([0, 1], ls="--")
    ax.plot([0, 0], [1, 0], c=".7"), plt.plot([1, 1], c=".7")
    ax.legend()

    plt.title('Receiver Operating Characteristic (ROC)', size=16)
    plt.ylabel('True Positive Rate', size=16)
    plt.xlabel('False Positive Rate', size=16)