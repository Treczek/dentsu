import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

import seaborn as sns
sns.set_context(font_scale=1.2)


def create_palette(series, high='green', medium='gray', low='red'):

    """
    Palette creation that might be used in a different seaborn plots
    :param series: series for which color palette should be created
    :param high, medium, low: colors for different value level
    :return: list of colors for each value in the series
    """

    clrs = list()
    for value in series:
        if value > series.quantile(0.75):
            color = high
        elif value < series.quantile(0.25):
            color = low
        else:
            color = medium
        clrs.append(color)
    return clrs


def build_dashboard_for_numerical_features(data, feature, target_dependency_bins=8):

    """
    :param data: whole dataset
    :param feature - feature for which we will build distribution dashboards
    :param target_dependency_bins: bins used in the target dependency plot. Default=8
    """

    # Creating Figure and title.
    fig = plt.figure(constrained_layout=True, figsize=(13, 9), dpi=100)
    fig.text(0.05, 0.85, feature.upper(), fontsize=30)

    # Creating grid and axes.
    spec = gridspec.GridSpec(ncols=4, nrows=5, figure=fig)
    ax1 = fig.add_subplot(spec[1:3, :3])
    ax2 = fig.add_subplot(spec[1:5, 3:])
    ax3 = fig.add_subplot(spec[3:5, :3])

    # Three different approaches for visualization of target dependency
    kde_true = sns.kdeplot(data.loc[data['y'], feature], color="green", shade=True, ax=ax1, label="Success")
    sns.kdeplot(data.loc[~data['y'], feature], color="gray", shade=True, ax=ax1, label="Failure")
    kde_true.set_ylabel('Distribution')

    sns.boxplot(y=data[feature], color="lightgray", ax=ax2, orient='v')

    target_plot_data = (data
                        .groupby(pd.cut(data[feature], target_dependency_bins, precision=0))
                        .agg({'y': ['mean', 'count']})
                        .reset_index())

    values = target_plot_data[('y', 'mean')]

    target_plot = sns.barplot(target_plot_data[feature], y=values, palette=create_palette(values), ax=ax3, alpha=0.4)
    target_plot.set_ylabel("Success rate")
    target_plot.set_xticklabels(target_plot.get_xticklabels(), rotation=20)


def build_dashboard_for_categorical_features(data, feature):
    barplot_colors = ('#90c979', '#b7c2b2', '#c9574b')
    to_plot = data.groupby(feature, sort=False, as_index=False).agg({'y': ['mean', 'count']})

    n_categories = data[feature].nunique()
    fig, axes = plt.subplots(2, 1, figsize=(min(15, 4 * n_categories),
                                            min(10, n_categories * 3)))

    # Title
    plt.suptitle(feature.upper() + '\n', fontsize=22, va='bottom')

    # Count plot at the top of the figure
    counts = sns.countplot(data=data,
                           x=feature,
                           ax=axes[0],
                           palette=create_palette(to_plot[('y', 'count')], *barplot_colors))

    counts.set_ylabel('counts', fontsize=18)

    # Bar plot at the bottom of the figure
    success_rates = sns.barplot(y=to_plot[('y', 'mean')],
                                x=to_plot[feature],
                                palette=create_palette(to_plot[('y', 'mean')], *barplot_colors),
                                ax=axes[1])

    success_rates.set_ylabel('Success rate', fontsize=18)
    plt.tight_layout()
